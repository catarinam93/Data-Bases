import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
from flask import abort, render_template, Flask
import logging
import db

APP = Flask(__name__)

# Start page
@APP.route('/')
def index():
    stats = {}
    x = db.execute('SELECT COUNT(*) AS clients FROM CLIENT').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS accounts FROM ACCOUNT').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS loans FROM LOANS').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS opens FROM OPEN').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS managers FROM MANAGER').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS sents FROM SENT').fetchone()
    stats.update(x)
    x = db.execute('SELECT COUNT(*) AS receiveds FROM RECEIVED').fetchone()
    stats.update(x)
    
    return render_template('index.html',stats=stats)

# Account page
@APP.route('/account/')
def list_account():
    accounts = db.execute(
      '''
      SELECT  Account_Id, Holder, Money, DestinationAccount_Id
      FROM ACCOUNT
      ORDER BY Account_Id
      '''
    ).fetchall()
    return render_template('account.html', accounts=accounts)

# Account Id
@APP.route('/account/<int:id>/')
def get_account(id):
    account = db.execute(
        '''
      SELECT  Account_Id, Holder, Money, DestinationAccount_Id
      FROM ACCOUNT WHERE Account_Id = %s
        ''',
        id
    ).fetchone()

    if account is None:
        abort(404, 'Account id {} does not exist.'.format(id))

    return render_template('account_id.html', account=account)

# Client page
@APP.route('/client/')
def list_client():
    clients = db.execute(
        '''
        SELECT Client_Id, Job, Marital_status, Qualifications, Age, Country, Name, Gender
        FROM CLIENT
        ORDER BY Client_Id
        '''
    ).fetchall()
    return render_template('client.html', clients=clients)

# Client Id
@APP.route('/client/<int:id>/')
def get_client(id):
    client = db.execute(
        '''
SELECT Client_Id, Job, Marital_status, Qualifications, Age, Country, Name, Gender
        FROM CLIENT WHERE Client_Id = %s
        ''',
        id
    ).fetchone()

    if client is None:
        abort(404, 'Client id {} does not exist.'.format(id))

    return render_template('client_id.html', client=client)

# Manager page
@APP.route('/manager/')
def list_manager():
    managers=db.execute(
    '''
    SELECT Manager_Id, Contact
    FROM MANAGER
    ORDER BY Manager_Id
    ''').fetchall()
    return render_template('manager.html', managers=managers)

# Manager Id
@APP.route('/manager/<int:id>/')
def get_manager(id):
    manager = db.execute(
        '''
    SELECT Manager_Id, Contact
    FROM MANAGER WHERE Manager_Id= %s
        ''',
        id
    ).fetchone()
    
    if manager is None:
        abort(404, 'Manager id {} does not exist.'.format(id))

    return render_template('manager_id.html', manager=manager)

# Loan page
@APP.route('/loans/')
def list_loans():
    loans=db.execute(
    '''
    SELECT Loan_Id, Loan_Holder, Category
    FROM LOANS
    ORDER BY Loan_Id
    ''').fetchall()
    return render_template('loans.html', loans=loans)

# Load Id
@APP.route('/loans/<string:id>/')
def get_loans(id):
    loan = db.execute(
        '''
    SELECT Loan_Id, Loan_Holder, Category
    FROM LOANS WHERE Loan_Id = %s
        ''',
        id
    ).fetchone()

    if loan is None:
        abort(404, 'Loan id {} does not exist.'.format(id))

    return render_template('loans_id.html', loan=loan)

# Open page
@APP.route('/open/')
def list_open():
    opens = db.execute(
      '''
      SELECT Client, Account, Date
      FROM OPEN
      ORDER BY Client
      '''
    ).fetchall()
    return render_template('open.html', opens=opens)

# Open Id
@APP.route('/open/<int:id>/')
def get_open(id):
    open = db.execute(
        '''
SELECT Client, Account, Date
      FROM OPEN WHERE Client = %s
        ''',
        id
    ).fetchone()

    if open is None:
        abort(404, 'Open id {} does not exist.'.format(id))

    return render_template('open_id.html', open=open)

#Sent page
@APP.route('/sent/')
def list_sent():
    sents = db.execute(
      '''
      SELECT Source_Account_s, Destination_Account_s, Amount_Sent
      FROM SENT
      ORDER BY Source_Account_s
      '''
    ).fetchall()
    return render_template('sent.html', sents=sents)

#Received page
@APP.route('/received/')
def list_received():
    receiveds = db.execute(
      '''
      SELECT Source_Account_r, Destination_Account_r, Amount_Received
      FROM RECEIVED
      ORDER BY Source_Account_r
      '''
    ).fetchall()
    return render_template('received.html', receiveds=receiveds)

@APP.route('/info/')
def list_info():
    # Número de Pessoas com saldo negativo, Número de Homens e mulheres
    indebt = db.execute(
        '''
        SELECT COUNT(*) AS N
        FROM ACCOUNT
        WHERE MONEY<0;
        '''
    ).fetchone()
 
    female = db.execute(
        '''
        SELECT COUNT(*) AS F FROM CLIENT WHERE GENDER = 'Female';
        '''
    ).fetchone()
 
    male = db.execute(
        '''
        SELECT COUNT(*) AS M FROM CLIENT WHERE GENDER = 'Male';
        '''
    ).fetchone()
    return render_template('info.html',indebt=indebt,female=female,male=male)

@APP.route('/clientLoan/')
def list_accountLoan():
    info = db.execute(
    '''
    SELECT NAME, COUNT(*) AS N
    FROM CLIENT JOIN ACCOUNT
    ON(ACCOUNT.Holder = CLIENT.Client_Id)
    JOIN LOANS ON(LOANS.Loan_Holder = CLIENT.Client_Id)
    GROUP BY Client_Id;
 
    ''').fetchall()
    return render_template('client_loan.html', info=info)

#Endpoint de pesquisa pelo nome de um certo cliente
@APP.route('/client/search/<expr>/')
def search_movie(expr):
  search = { 'expr': expr }
  expr = '%' + expr + '%'
  names = db.execute(
      ''' 
      SELECT Client_Id, Job, Marital_Status, Qualifications, Age, Country, Name, Gender
      FROM CLIENT
      WHERE Name LIKE %s
      ''', expr).fetchall()
  return render_template('client-search.html', search=search, names=names)